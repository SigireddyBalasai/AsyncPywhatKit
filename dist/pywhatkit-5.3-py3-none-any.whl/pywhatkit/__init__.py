# Version 5.2
# Status: Stable
# Documentation: https://github.com/Ankit404butfound/PyWhatKit/wiki
# Report Bugs and Feature Requests here: https://github.com/Ankit404butfound/PyWhatKit/issues
# For further Information, Join our Discord: https://discord.gg/62Yf5mush
from .async_pywhat import *
from .sync_pywhat import *

